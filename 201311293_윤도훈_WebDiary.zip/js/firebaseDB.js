var database = firebase.database();
var note = "";
var title = "";
var time = "";
var id = "";
var tag = "";
var tag2 = "";
var temp = "";

///
var DELAY = 200, clicks = 0, timer = null;
///

function loadDB() {
	$("#staggered-test").empty();
	database.ref('note').on("value", function(snapshot) {
		snapshot.forEach(function(childSnapshot) {
			var t = childSnapshot.child("title").val();
			var n = childSnapshot.child("note").val();
			var i = childSnapshot.child("id").val();
			var g = childSnapshot.child("tag").val();
			createNote(n, t, i, g);
		});
	});
}

function searchNote(index) {
	console.log("Search testing");
	$("#staggered-test").empty();
	database.ref('note').on("value", function(snapshot) {
		snapshot.forEach(function(childSnapshot) {
			var tag = childSnapshot.child("tag").val();
			for (var i = 0; i < tag.length; i++) {
				if(tag[i] == index) {
					var t = childSnapshot.child("title").val();
					var n = childSnapshot.child("note").val();
					var i = childSnapshot.child("id").val();
					createSearch(n, t, i, tag);
				}//if
			}//for
		});
	});
}

function deleteNote(index) {
	database.ref('note/' + index).remove();
	location.reload();
}

function editNote(index) {
	$('#modal1').modal();
    $('#modal1').modal('open'); 

    database.ref('note/' + index).on("value", function(snapshot) {
    	var t = snapshot.child("title").val();
    	var n = snapshot.child("note").val();
    	var g = snapshot.child("tag").val();
    	$("#note_title").val(t);
		$("#note_note").val(n);
		$("#note_tag").val(g);
    });
	
	$("#save").on("click", function() {
		var d = new Date();
		time = d.toUTCString();
		var title = $("#note_title").val();
		var note = $("#note_note").val();
		var tag = $("#note_tag").val();
		tag = tag.split(' ');

		for (var i = 0; i < tag.length; i++) {
			tag[i] = "#" + tag[i];
		}

		if(title == "" || note == "" || tag == "")
			alert("Must fill the blank");
		else {
			database.ref('note/' + index).set({
				id: index,
				title: title,
				note: note,
				time: time,
				tag: tag
			})
		}
		location.reload();
	});
}

function createSearch(note, title, id, tag) {
	var hr = document.createElement("hr");

	var title_h4 = document.createElement("h4");
	var title_a = document.createElement("a");
	var title_text  = document.createTextNode(title);
	title_a.appendChild(title_text);
	title_h4.appendChild(title_a);
	
	var note_p = document.createElement("p");
	var note_text = document.createTextNode(note);
	note_p.appendChild(note_text);
	note_p.setAttribute("class", "truncate");
	note_p.style.fontSize = "20px";
	note_p.style.fontFamily = "verdana";

	var tag_p = document.createElement("p");
	var tag_text = document.createTextNode(tag);
	tag_p.appendChild(tag_text);
	tag_p.style.color = "#03a9f4";

	var list = document.createElement("li");
	list.appendChild(title_h4);
	list.appendChild(note_p);
	list.appendChild(tag_p);
	list.appendChild(hr);
	list.setAttribute("class", "note_list hoverable");
	list.setAttribute("id", id);

	var ul = document.getElementById("staggered-test");
	ul.appendChild(list);
}

function createNote(note, title, id, tag) {
	var hr = document.createElement("hr");

	var title_h4 = document.createElement("h4");
	var title_a = document.createElement("a");
	var title_text  = document.createTextNode(title);
	title_a.appendChild(title_text);
	title_h4.appendChild(title_a);
	
	var note_p = document.createElement("p");
	var note_text = document.createTextNode(note);
	note_p.appendChild(note_text);
	note_p.setAttribute("class", "truncate");
	note_p.style.fontSize = "20px";
	note_p.style.fontFamily = "verdana";

	var tag_p = document.createElement("p");
	var tag_text = document.createTextNode(tag);
	tag_p.appendChild(tag_text);
	tag_p.style.color = "#03a9f4";

	var list = document.createElement("li");
	list.appendChild(title_h4);
	list.appendChild(note_p);
	list.appendChild(tag_p);
	list.appendChild(hr);
	list.setAttribute("class", "note_list hoverable");
	list.setAttribute("id", id);

	var ul = document.getElementById("staggered-test");
	ul.appendChild(list);

	setStyle();
}

function setStyle() {
	var liList = document.getElementsByClassName("note_list");
	for (var i = 0; i < liList.length; i++) {
		liList[i].style.transform = "translateX(0px)";
		liList[i].style.opacity = 0;
	}
	var aList = document.getElementsByTagName("a");
	for (var i = 0; i < aList.length; i++) {
		aList[i].setAttribute("href", "#");
	}
}

$("#sndbtn").on("click", function() {
	var data = $('.chips-placeholder').material_chip('data');
	for (var i = 0; i < data.length; i++) {
		temp += "#" + data[i].tag + " ";
	}
	tag = temp.split(' ');
	note = CKEDITOR.instances.editor1.getData();
	title = $("#last_name").val();
	var d = new Date();
	time = d.toUTCString();

	// DB에 추가
	if(title == "" || note == "") {
		alert("No Title OR No Note");
	}
	else {
		Materialize.toast('Uploaded !', 4000);
		id = database.ref('note').push().key;	
		database.ref('note/' + id).set({
			id: id,
			title: title,
			note: note,
			time: time,
			tag: tag
		});	
	}
	
	location.reload();

	$("#last_name").val(" ");
	CKEDITOR.instances.editor1.setData() = " ";	
});

$("#staggered-test").on("click", "li", function() {
	clicks++;
	if(clicks == 1) {
		var index = this.id;
		timer = setTimeout(function() {	
			/// SingleClick Work
			var confirmAns = confirm("=== Edit Note?? ===");
			if(confirmAns) {
    			editNote(index);
			}

			///

			clicks = 0;
		}, DELAY);
	}
	else {
		clearTimeout(timer);
			/// DoubleClick Work
			var index = this.id;
			var confirmAns = confirm("=== Delete Note?? ===");
			if(confirmAns) {
				deleteNote(index);
			}

			///

			clicks = 0;
		}
	})
.on("dbclick", function() {
	e.preventDefault();
});

$("#go").on("click", function() {
	var tag = $("#search").val();
	tag = "#" + tag;
	searchNote(tag);
});