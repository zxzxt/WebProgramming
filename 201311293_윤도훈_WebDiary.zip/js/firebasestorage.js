var storage = firebase.storage();
var index = 0;

$("#upload").on("click", function() {
  var confirmAns = confirm("===Upload ???===");
    if(confirmAns) {
      var fileName = $("#fileName").val();
      var ext = $('#fileName').val().split('.').pop().toLowerCase();
      var file_data = $("#image").prop("files")[0];

      if(fileName == "") {
        alert("No File Uploaded !");
      }
      else if($.inArray(ext, ['png','jpg', 'jpeg']) == 1) {
        storage.ref("images/" + fileName).put(file_data);      
      }
      else if($.inArray(ext, ['mp4','avi', 'mkv']) == 1) {
        storage.ref("videos/" + fileName).put(file_data);  
      }
      else {
        storage.ref("files/" + fileName).put(file_data);  
      }
      
    }
    
    // 업로드버튼 누르면 카드에 이미지 추가
    if($.inArray(ext, ['png','jpg', 'jpeg']) == 1) {
      createPhoto();
      var image = document.getElementsByTagName("img");
      var dir = "images/";
      image[index].setAttribute("src", dir + fileName);
      index++;
    }
    
  $("#fileName").val(" ");

});

/*
function loadStorage() {
  for (var i = 0; i < imgarr.length; i++) {
    createPhoto();
    var imgList = document.getElementsByTagName("img");
    storage.ref('images/' + imgarr[i]).getDownloadURL().then(function(url) {
      document.querySelector(imgList[i]).src = url;
    });
  }//for
}//load
*/
function createPhoto() {
  var img = document.createElement("img");
  var sticky = document.getElementById("sticky");
  var br = document.createElement("br");
  img.setAttribute("class", "activator");
  sticky.appendChild(img);
  img.appendChild(br);
}
