$('.chips-placeholder').material_chip({
	placeholder: 'Enter a tag',
	secondaryPlaceholder: '+Tag',
});



CKEDITOR.addCss(".cke_editable{background-color : #bcaaa4}");